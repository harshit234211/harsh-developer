const terminal = document.getElementById('terminal');
const input = document.getElementById('cmdInput');
const btn = document.getElementById('btnExecute');

function log(text, type = 'user') {
  const line = document.createElement('div');
  line.className = 'log-line ' + type;
  line.textContent = text;
  terminal.appendChild(line);
  terminal.scrollTop = terminal.scrollHeight;
}

btn.addEventListener('click', () => {
  const cmd = input.value.trim();
  if (!cmd) return;
  log('❯ ' + cmd, 'user');
  input.value = '';

  setTimeout(() => {
    if (cmd.includes('index')) {
      log('[OK] Scanned workspace: 1,482 files indexed. 0 duplicates found.', 'system');
    } else if (cmd.includes('scrape')) {
      log('[OK] Headless scraper spawned: 48 data points extracted to CSV.', 'system');
    } else {
      log('[OK] Command routed to Jarvis Automation Core.', 'system');
    }
  }, 400);
});
