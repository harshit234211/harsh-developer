# Jarvis AI — Complete PC Desktop Source Code Package
**Version**: v3.1.2  
**Target Platform**: Windows 10/11, macOS, Linux  
**Author**: DEVCRAFT Studio (Harsh Developer)  
**Website**: https://harsh-developer.onrender.com

---

## What is Included:
1. Electron Host Application with frameless glassmorphic HUD.
2. Global hotkey listener on Ctrl + Space.
3. Python Automation Core (system actions, web scraper, Ollama/local LLM bridge).
4. Build Configuration for Windows, Mac, and Linux.

## How to Build & Run:
1. Install dependencies:
   `npm install`
   `pip install -r requirements.txt`
2. Start development mode:
   `npm start`
3. Build production executable installer for Windows (.exe):
   `npm run build:win`
4. Press Ctrl + Space anywhere on your PC to trigger the Jarvis HUD!
