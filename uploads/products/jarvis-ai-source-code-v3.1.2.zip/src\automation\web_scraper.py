import urllib.request
import re

def scrape_page_titles(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'JarvisAI/3.1'})
    with urllib.request.urlopen(req) as response:
        html = response.read().decode('utf-8')
        titles = re.findall(r'<title>(.*?)</title>', html)
        return titles

if __name__ == "__main__":
    print(scrape_page_titles("https://harsh-developer.onrender.com"))
