import os
import sys
import json
import time

def list_system_metrics():
    return {
        "status": "active",
        "cpu_usage": "14%",
        "ram_allocated": "412MB",
        "hotkey": "Ctrl+Space"
    }

if __name__ == "__main__":
    print(json.dumps(list_system_metrics()))
    sys.stdout.flush()
