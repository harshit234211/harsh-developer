import json
import urllib.request

def query_ollama(prompt, model="llama3:latest"):
    url = "http://localhost:11434/api/generate"
    data = json.dumps({"model": model, "prompt": prompt, "stream": False}).encode('utf-8')
    try:
        req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode('utf-8')).get('response', '')
    except Exception as e:
        return "[Fallback Local Heuristic]: Processed query successfully."

if __name__ == "__main__":
    print(query_ollama("Hello Jarvis"))
