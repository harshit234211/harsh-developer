package com.devcraft.joya.automation

import android.content.Context
import android.content.Intent
import android.net.Uri

class WhatsAppAutomator(private val context: Context) {
    fun dispatchQuickMessage(message: String, phoneWithCountryCode: String = "918791984082") {
        try {
            val url = "https://api.whatsapp.com/send?phone=" + phoneWithCountryCode + "&text=" + Uri.encode(message)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
