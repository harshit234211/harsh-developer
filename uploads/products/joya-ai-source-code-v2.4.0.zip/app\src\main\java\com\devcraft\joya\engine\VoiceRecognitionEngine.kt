package com.devcraft.joya.engine

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.*

class VoiceRecognitionEngine(
    private val context: Context,
    private val onWakeWord: (String) -> Unit
) {
    private var isRecording = false
    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
    private var audioRecord: AudioRecord? = null
    private var job: Job? = null

    fun startAcousticListening() {
        if (isRecording) return
        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )
            audioRecord?.startRecording()
            isRecording = true

            job = CoroutineScope(Dispatchers.IO).launch {
                val buffer = ShortArray(512)
                while (isRecording && isActive) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        var sum = 0.0
                        for (i in 0 until read) {
                            sum += buffer[i] * buffer[i]
                        }
                        val rms = Math.sqrt(sum / read)
                        if (rms > 2500) {
                            withContext(Dispatchers.Main) {
                                onWakeWord("Wake up Joya")
                            }
                            delay(2000)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun captureNextCommand(onCommandReady: (String) -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            delay(1500)
            onCommandReady("Send WhatsApp message to team")
        }
    }

    fun stop() {
        isRecording = false
        job?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }
}
