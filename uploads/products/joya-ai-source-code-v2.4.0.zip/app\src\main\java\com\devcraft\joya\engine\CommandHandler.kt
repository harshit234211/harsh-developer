package com.devcraft.joya.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.devcraft.joya.automation.WhatsAppAutomator

class CommandHandler(
    private val context: Context,
    private val tts: TextToSpeechEngine
) {
    private val whatsApp = WhatsAppAutomator(context)

    fun execute(command: String) {
        val lower = command.lowercase()
        when {
            "whatsapp" in lower -> {
                tts.speak("Opening WhatsApp dispatch...")
                whatsApp.dispatchQuickMessage("DevCraft Project Status: All systems nominal.")
            }
            "call" in lower -> {
                tts.speak("Dialing client line...")
                val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+917017022966"))
                callIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(callIntent)
            }
            "alarm" in lower || "timer" in lower -> {
                tts.speak("Setting automation timer for 30 minutes.")
            }
            else -> {
                tts.speak("Command processed: " + command)
            }
        }
    }
}
