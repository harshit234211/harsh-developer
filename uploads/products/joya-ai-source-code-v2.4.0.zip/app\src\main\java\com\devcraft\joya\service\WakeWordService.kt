package com.devcraft.joya.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.devcraft.joya.MainActivity
import com.devcraft.joya.R
import com.devcraft.joya.engine.CommandHandler
import com.devcraft.joya.engine.TextToSpeechEngine
import com.devcraft.joya.engine.VoiceRecognitionEngine
import kotlinx.coroutines.*

class WakeWordService : Service() {

    private val CHANNEL_ID = "JoyaWakeWordChannel"
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private lateinit var tts: TextToSpeechEngine
    private lateinit var voiceEngine: VoiceRecognitionEngine
    private lateinit var commandHandler: CommandHandler

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeechEngine(this)
        commandHandler = CommandHandler(this, tts)
        voiceEngine = VoiceRecognitionEngine(this) { detectedPhrase ->
            onWakeWordDetected(detectedPhrase)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Joya AI Voice Sentinel")
            .setContentText("Listening for 'Wake up Joya' in low-power background mode...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(1001, notification)
        voiceEngine.startAcousticListening()
        return START_STICKY
    }

    private fun onWakeWordDetected(phrase: String) {
        tts.speak("I am listening, how can I help?")
        voiceEngine.captureNextCommand { userCommand ->
            commandHandler.execute(userCommand)
        }
    }

    override fun onDestroy() {
        voiceEngine.stop()
        tts.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Joya Background Listener",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
