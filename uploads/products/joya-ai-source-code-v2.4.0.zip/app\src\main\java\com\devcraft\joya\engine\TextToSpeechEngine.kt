package com.devcraft.joya.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.*

class TextToSpeechEngine(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context, this)
    private var isReady = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.ENGLISH
            tts.setPitch(1.05f)
            tts.setSpeechRate(0.98f)
            isReady = true
        }
    }

    fun speak(text: String) {
        if (isReady) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JoyaSpeech")
        }
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
