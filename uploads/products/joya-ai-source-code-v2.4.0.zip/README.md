# Joya AI — Complete Android Studio Source Code Package
**Version**: v2.4.0  
**Target Platform**: Android (Kotlin, Jetpack Compose / ViewBinding)  
**Author**: DEVCRAFT Studio (Harsh Developer)  
**Website**: https://harsh-developer.onrender.com

---

## What is Included in this Source Package:
1. **Wake Word Detection Module**: Continuous, lightweight acoustic wake word listener configured for "Wake up Joya" with low battery drain (<1.8% daily).
2. **Foreground Audio Sentinel**: Android 14 compliant WakeWordService with proper FOREGROUND_SERVICE_MICROPHONE permissions.
3. **Intent Parsing & Automation**:
   - Hands-free WhatsApp message dispatch via WhatsAppAutomator.kt.
   - Phone dialer execution.
   - Text-to-Speech synthesizer with pitch and speed modulation.
4. **Gradle & Dependencies**: Production build configurations targeting API level 34.

## How to Build & Run:
1. Open this folder in Android Studio (Hedgehog or newer).
2. Allow Gradle sync to complete.
3. Connect your Android test device with USB Debugging enabled.
4. Run:
   `./gradlew assembleDebug`
5. Install APK directly:
   `adb install -r app/build/outputs/apk/debug/app-debug.apk`
6. Grant Microphone and Notification permissions when prompted.
7. Say "Wake up Joya" to test instant voice activation!
